package com.jeeva.focusflow;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.accessibility.AccessibilityEvent;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class FocusAccessibilityService extends AccessibilityService {
    private long lastLaunch=0;
    @Override public void onAccessibilityEvent(AccessibilityEvent event){
        if(event==null||event.getPackageName()==null)return;
        SharedPreferences p=getSharedPreferences(MainActivity.PREFS,MODE_PRIVATE);
        if(p.getLong("session_end",0)<=System.currentTimeMillis())return;
        Set<String> selected=p.getStringSet("blocked_apps",null);
        if(selected==null)selected=new HashSet<>(Arrays.asList("com.instagram.android","com.snapchat.android","com.google.android.youtube"));
        if(!selected.contains(event.getPackageName().toString()))return;
        long now=System.currentTimeMillis();if(now-lastLaunch<1000)return;lastLaunch=now;
        Intent i=new Intent(this,BlockedActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);startActivity(i);
    }
    @Override public void onInterrupt(){}
}
