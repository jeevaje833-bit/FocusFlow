package com.jeeva.focusflow;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.*;
import android.graphics.Color;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    public static final String PREFS="focusflow_prefs";
    private static final String CHANNEL="focusflow_sessions";
    private SharedPreferences prefs;
    private TextView timer,status,goal,progressText,appsText;
    private final Handler handler=new Handler();
    private int selectedMinutes=25;
    private boolean completing=false;
    private final int bg=Color.rgb(13,20,28),panel=Color.rgb(25,36,44),lime=Color.rgb(199,240,90),white=Color.WHITE,muted=Color.rgb(165,178,180);
    private final Runnable ticker=new Runnable(){public void run(){updateTimer();handler.postDelayed(this,1000);}};

    @Override protected void onCreate(Bundle b){super.onCreate(b);prefs=getSharedPreferences(PREFS,MODE_PRIVATE);resetDailyIfNeeded();createChannel();buildUi();handler.post(ticker);}
    private TextView txt(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}
    private Button btn(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);return b;}
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);l.setPadding(22,18,22,18);l.setBackgroundColor(bg);return l;}
    private LinearLayout card(LinearLayout root){LinearLayout c=new LinearLayout(this);c.setOrientation(1);c.setPadding(18,18,18,18);c.setBackgroundColor(panel);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,18,0,12);root.addView(c,p);return c;}
    private void buildUi(){
        ScrollView scroll=new ScrollView(this);LinearLayout root=col();root.setPadding(24,28,24,28);scroll.addView(root);
        root.addView(txt("focusflow",30,lime));root.addView(txt("YOUR PERSONAL STUDY SPACE",11,muted));
        TextView hello=txt("Make today count 👋",25,white);hello.setPadding(0,24,0,4);root.addView(hello);root.addView(txt("Small focused sessions. Real progress.",14,muted));
        LinearLayout focus=card(root);focus.addView(txt("FOCUS SESSION",12,lime));timer=txt("25:00",56,white);timer.setGravity(Gravity.CENTER);timer.setPadding(0,12,0,4);focus.addView(timer);status=txt("Ready when you are",14,muted);status.setGravity(Gravity.CENTER);status.setPadding(0,0,0,12);focus.addView(status);
        LinearLayout modes=new LinearLayout(this);modes.setGravity(Gravity.CENTER);String[] labels={"25 min","50 min","90 min"};int[] mins={25,50,90};for(int i=0;i<3;i++){final int m=mins[i];Button b=btn(labels[i]);b.setOnClickListener(v->{if(!running()){selectedMinutes=m;updateTimer();}});modes.addView(b,new LinearLayout.LayoutParams(0,-2,1));}focus.addView(modes);
        Button start=btn("▶  Start focus");start.setOnClickListener(v->startSession());focus.addView(start);Button stop=btn("End session");stop.setOnClickListener(v->endSession(false));focus.addView(stop);
        LinearLayout stats=card(root);stats.addView(txt("TODAY'S PROGRESS",12,lime));goal=txt("0 / 360 min",25,white);goal.setPadding(0,8,0,4);stats.addView(goal);ProgressBar bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);bar.setMax(960);bar.setProgress((int)(prefs.getLong("today_ms",0)/60000));stats.addView(bar,new LinearLayout.LayoutParams(-1,12));progressText=txt("Daily goal: 6 hours",13,muted);progressText.setPadding(0,8,0,0);stats.addView(progressText);
        LinearLayout shield=card(root);shield.addView(txt("YOUR FOCUS SHIELD",12,lime));appsText=txt("Apps selected: "+blockedApps().size(),14,white);appsText.setPadding(0,8,0,4);shield.addView(appsText);Button picker=btn("Choose distracting apps");picker.setOnClickListener(v->showAppPicker());shield.addView(picker);Button permission=btn("Enable app-blocking permission");permission.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));shield.addView(permission);shield.addView(txt("Blocking is active only during a focus session. Enable FocusFlow in Android Accessibility settings.",12,muted));
        LinearLayout more=card(root);more.addView(txt("STUDY ROUTINE",12,lime));Button change=btn("Change daily goal");change.setOnClickListener(v->changeGoal());more.addView(change);Button history=btn("View focus history");history.setOnClickListener(v->showHistory());more.addView(history);root.addView(txt("Your study data stays on this phone. No account or internet connection is required.",12,muted));setContentView(scroll);refreshStats();updateTimer();
    }
    private boolean running(){return prefs.getLong("session_end",0)>System.currentTimeMillis();}
    private void startSession(){if(running()){Toast.makeText(this,"A focus session is already running",Toast.LENGTH_SHORT).show();return;}long now=System.currentTimeMillis(),duration=selectedMinutes*60000L;prefs.edit().putLong("session_start",now).putLong("session_end",now+duration).putLong("session_duration",duration).apply();completing=false;status.setText("Focus shield active • Stay on task");showNotification();updateTimer();}
    private void endSession(boolean complete){long start=prefs.getLong("session_start",0),end=prefs.getLong("session_end",0);if(start>0&&end>0){long duration=prefs.getLong("session_duration",end-start);long elapsed=complete?duration:Math.max(0,Math.min(System.currentTimeMillis(),end)-start);if(elapsed>0)addFocus(elapsed);prefs.edit().putLong("session_start",0).putLong("session_end",0).putLong("session_duration",0).apply();}((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).cancel(1001);status.setText(complete?"Session complete 🎉 Great work!":"Session ended. Every minute counts.");updateTimer();refreshStats();}
    private void addFocus(long ms){resetDailyIfNeeded();prefs.edit().putLong("today_ms",prefs.getLong("today_ms",0)+ms).putLong("all_time_ms",prefs.getLong("all_time_ms",0)+ms).putInt("sessions_today",prefs.getInt("sessions_today",0)+1).apply();}
    private void updateTimer(){if(timer==null)return;long end=prefs.getLong("session_end",0),left=Math.max(0,end-System.currentTimeMillis());if(end>0&&left==0&&!completing){completing=true;endSession(true);return;}if(end>0)timer.setText(String.format(Locale.getDefault(),"%02d:%02d",left/60000,(left/1000)%60));else timer.setText(String.format(Locale.getDefault(),"%02d:00",selectedMinutes));}
    private void resetDailyIfNeeded(){String today=new SimpleDateFormat("yyyyMMdd",Locale.US).format(new Date());if(!today.equals(prefs.getString("day_key","")))prefs.edit().putString("day_key",today).putLong("today_ms",0).putInt("sessions_today",0).apply();}
    private void refreshStats(){if(goal==null)return;long m=prefs.getLong("today_ms",0)/60000;int target=prefs.getInt("daily_goal",360);goal.setText(m+" / "+target+" min");progressText.setText(m>=target?"🎉 Daily goal reached!": "Daily goal: "+(target/60)+" hours • "+(target-m)+" min to go");appsText.setText("Apps selected: "+blockedApps().size());}
    private Set<String> blockedApps(){Set<String>s=prefs.getStringSet("blocked_apps",null);if(s==null)return new HashSet<>(Arrays.asList("com.instagram.android","com.snapchat.android","com.google.android.youtube"));return new HashSet<>(s);}
    private void showAppPicker(){PackageManager pm=getPackageManager();Intent query=new Intent(Intent.ACTION_MAIN,null);query.addCategory(Intent.CATEGORY_LAUNCHER);List<ResolveInfo> list=pm.queryIntentActivities(query,0);Collections.sort(list,(a,b)->String.valueOf(a.loadLabel(pm)).compareToIgnoreCase(String.valueOf(b.loadLabel(pm))));ArrayList<String> pkgs=new ArrayList<>(),labels=new ArrayList<>();Set<String> old=blockedApps();boolean[] checked=new boolean[list.size()];for(ResolveInfo r:list){String p=r.activityInfo.packageName;if(p.equals(getPackageName()))continue;pkgs.add(p);labels.add(String.valueOf(r.loadLabel(pm)));}checked=new boolean[pkgs.size()];for(int i=0;i<pkgs.size();i++)checked[i]=old.contains(pkgs.get(i));final boolean[] state=checked;new AlertDialog.Builder(this).setTitle("Choose apps to block").setMultiChoiceItems(labels.toArray(new String[0]),state,(d,w,on)->state[w]=on).setPositiveButton("Save",(d,w)->{HashSet<String> save=new HashSet<>();for(int i=0;i<pkgs.size();i++)if(state[i])save.add(pkgs.get(i));prefs.edit().putStringSet("blocked_apps",save).apply();refreshStats();Toast.makeText(this,"Focus shield updated",Toast.LENGTH_SHORT).show();}).setNegativeButton("Cancel",null).show();}
    private void changeGoal(){EditText e=new EditText(this);e.setInputType(2);e.setText(String.valueOf(prefs.getInt("daily_goal",360)/60));new AlertDialog.Builder(this).setTitle("Daily goal in hours (1–16)").setView(e).setPositiveButton("Save",(d,w)->{try{int h=Integer.parseInt(e.getText().toString());if(h<1||h>16)throw new Exception();prefs.edit().putInt("daily_goal",h*60).apply();refreshStats();}catch(Exception ex){Toast.makeText(this,"Enter a number from 1 to 16",Toast.LENGTH_SHORT).show();}}).setNegativeButton("Cancel",null).show();}
    private void showHistory(){String date=new SimpleDateFormat("dd MMM yyyy",Locale.getDefault()).format(new Date());new AlertDialog.Builder(this).setTitle("Focus history").setMessage("Today • "+date+"\nFocused: "+prefs.getLong("today_ms",0)/60000+" minutes\nSessions completed: "+prefs.getInt("sessions_today",0)+"\n\nAll-time focused: "+prefs.getLong("all_time_ms",0)/60000+" minutes").setPositiveButton("Close",null).show();}
    private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(CHANNEL,"Focus sessions",NotificationManager.IMPORTANCE_LOW);c.setDescription("FocusFlow session status");((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);}}
    private void showNotification(){Intent i=new Intent(this,MainActivity.class);PendingIntent p=PendingIntent.getActivity(this,0,i,PendingIntent.FLAG_UPDATE_CURRENT|(Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0));Notification n=new Notification.Builder(this,CHANNEL).setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("FocusFlow session active").setContentText("Your focus shield is on").setContentIntent(p).setOngoing(true).build();((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(1001,n);}
    @Override protected void onResume(){super.onResume();if(prefs!=null){resetDailyIfNeeded();refreshStats();updateTimer();}}
    @Override protected void onDestroy(){handler.removeCallbacks(ticker);super.onDestroy();}
}
