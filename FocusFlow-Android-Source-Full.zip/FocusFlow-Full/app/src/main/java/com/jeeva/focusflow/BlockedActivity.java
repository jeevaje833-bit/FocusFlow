package com.jeeva.focusflow;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

public class BlockedActivity extends Activity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this); root.setOrientation(1); root.setGravity(Gravity.CENTER); root.setPadding(32,32,32,32); root.setBackgroundColor(Color.rgb(16,24,32));
        TextView title = new TextView(this); title.setText("Stay with your goal ✨"); title.setTextColor(Color.rgb(199,240,90)); title.setTextSize(28); title.setGravity(Gravity.CENTER);
        TextView msg = new TextView(this); msg.setText("This app is paused during your FocusFlow study session. Your future self will thank you."); msg.setTextColor(Color.WHITE); msg.setTextSize(16); msg.setGravity(Gravity.CENTER); msg.setPadding(0,24,0,28);
        TextView back = new TextView(this); back.setText("RETURN TO STUDY"); back.setTextColor(Color.rgb(16,24,32)); back.setTextSize(15); back.setGravity(Gravity.CENTER); back.setPadding(24,18,24,18); back.setBackgroundColor(Color.rgb(199,240,90));
        back.setOnClickListener(v -> finish()); root.addView(title); root.addView(msg); root.addView(back); setContentView(root);
    }
    @Override public void onBackPressed() { super.onBackPressed(); }
}
