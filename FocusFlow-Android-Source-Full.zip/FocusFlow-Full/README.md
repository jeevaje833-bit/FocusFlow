# FocusFlow — Android study focus app

Native Android Java source project for a local-first study timer and distraction shield.

## Included
- Focus timer presets: 25, 50 and 90 minutes.
- Session state saved locally; completed and manually ended sessions add focus time.
- Daily focus total resets by calendar date; configurable 1–16 hour daily goal.
- All-time focus total and simple daily session history.
- App picker to select installed launcher apps to block.
- Accessibility-service blocker and return-to-study screen.
- Focus session status notification.
- No account, analytics SDK, ads, network permission, or cloud sync.

## Important limitations
- **This is source code, not a compiled or device-tested APK.** The build has not yet been run with Android SDK/Gradle in this environment.
- App blocking is best-effort, not tamper-proof. The user must enable FocusFlow under Android Settings → Accessibility. Android/OEM battery management may interrupt the service.
- If Android force-stops the app or the phone shuts down mid-session, that session may not be recorded.
- On Android 13+, notifications may be hidden until notification permission is granted in system settings; core timer/blocking does not require notifications.
- App picker displays launchable apps exposed by Android package visibility. Some system apps may not appear.
- Accessibility access is sensitive. The service checks foreground package names only; it does not read screen text or send data anywhere.

## Build an APK
1. Install Android Studio and Android SDK Platform 35.
2. Open this `FocusFlow-Full` folder in Android Studio and allow Gradle sync.
3. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. Install the generated debug APK on your phone.
5. Open FocusFlow → **Enable app-blocking permission** → enable FocusFlow in Accessibility settings.
6. Choose apps to block, start a focus session, and test the blocker.

Package: `com.jeeva.focusflow`  
Minimum Android: 8.0 (API 26)  
Target SDK: 35
